# 酷我来源说明

- 搜索及标准 MP3 地址：慕名接口，https://xiaoapi.cn/detail/7 ，入口 `/v1/music_kw.php`。使用 `action=search`、`msg`、`page`、`size`；播放使用 `action=play`、`rid`、`br=h`。页码与每页 30 条已按实际响应核验。
- 封面：同一搜索记录的酷我图片，针对 albumcover/starheads 的尺寸路径请求真实 700×700 版本，失败后尝试 500×500；不把 120×120 缩略图放大后作为高清封面。旧收藏保存的地址也在请求时升级，高清图片使用独立缓存，下载期间可显示旧缩略图。
- 歌词：同一歌曲 ID 的 `newlyric.kuwo.cn` 客户端歌词协议，转换成 UTF-8 逐行 LRC；带 `<0,0>` 的句末译文重新归到对应原文的开始时间，并同时间戳组合显示。协议研究参考 https://github.com/guohuiyuan/music-lib/tree/59dd7753bbc8/kuwo ；本项目独立实现解码、字符转换及时间标记清理。
- GB18030 字符映射由 `scripts/generate-gb18030-data.py` 使用 Python 标准 codec 生成，压缩数据在 `include/gb18030_data.hpp`，无需额外字符转换库。
- 不获取其他用户凭证、不处理加密付费音频、不保证每首搜索结果均可播放；接口拒绝或缺少地址时显示失败。

安装包不包含实测歌曲、歌词、封面或用户数据。
