# Pi Player 0.1.2

Nintendo Switch、Switch OLED、Switch Lite 音乐播放器，作者 LINKO。Tesla 菜单名称为 **Piplayer**，版本 **0.1.2**。

## 安装

将 `PiPlayer-0.1.2-Full-SD.zip` 完整解压并覆盖到 SD 卡根目录。主应用位于 `switch/piplayer/piplayer.nro`，Tesla 插件位于 `switch/.overlays/piplayer-overlay.ovl`。安装包包含后台播放模块及对应源码和许可证；首次安装后台模块后请重启主机。

## 功能

- 简体中文界面，在线歌曲搜索、缓存、封面和逐行歌词。
- 本地 MP3、FLAC、WAV 扫描，本地歌词、收藏及播放队列。
- Tesla 播放控制、音量、触摸拖动进度条、搜索和「停止并退出」。
- 程序绘制的 4 秒启动动画，歌曲列表和封面在动画期间继续后台加载。

音乐文件放入 `switch/piplayer/music/`，同名 LRC 可与歌曲放在同一目录。详见 LOCAL_MUSIC.txt。

## 构建

需要 devkitA64、libnx、Switch SDL2/SDL2_image/SDL2_ttf/SDL2_mixer、libcurl 等端口库。

```sh
bash tests/run.sh
make -j2
bash scripts/install-libtesla.sh
make overlay -j2
python3 scripts/verify-release-binaries.py
```

启动图形与动画源代码位于 `include/startup_animation.hpp` 和 `include/startup_vectors.hpp`。Linux GIF 绘图预览：

```sh
python3 scripts/render-startup-preview.py --gif preview.gif
```

## 音源说明

在线数据来自 yinyueku.cn，曲目可用性取决于站点返回结果和地区网络。请支持正版，使用有权访问的音源。本项目不包含歌曲文件，不绕过付费、DRM 或访问权限。

0.1.2：网络连接兼容重试、下载完整性检查、播放缓冲优化与快进歌词同步修复。详见 RELEASE_NOTES_0.1.2.md。
