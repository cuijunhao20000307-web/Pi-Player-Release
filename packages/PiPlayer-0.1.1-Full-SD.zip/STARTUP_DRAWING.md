# Procedural startup drawing

The 4-second intro is drawn from vector geometry in include/startup_animation.hpp and include/startup_vectors.hpp. The note is a hand-authored Bezier outline with a vertical pink gradient. Two water ripples are made from radial distance coverage with antialiased 1.3-unit wavefronts; their radii use cubic ease-out, with a short opacity attack and a delayed dissipation. the title and LINKO signature use vector outlines generated on Linux from DejaVu Sans. The lettering license is included in licenses/startup-lettering/LICENSE.txt.

No MP4, decoded video frame, PNG sprite sheet, or frame archive is read or embedded in the application. Four small textures are rasterized from these paths at startup, animated by elapsed milliseconds using SDL, and freed afterward. Shape memory is below 2 MiB, compared with the previous full-frame approach.

For a GIF preview, run `python3 scripts/render-startup-preview.py --gif preview.gif` on Linux with g++ and FFmpeg installed. The helper compiles tests/startup_render.cpp, which calls the very same buildArt(), scene() and geometry used by the Switch app. FFmpeg only encodes the newly drawn RGB output into GIF; there is no reference video input.

The redesign follows the supplied reference composition and timing. It is a drawing recreation and does not claim pixel equality to the reference video. Native Switch playback remains to be checked on hardware.
